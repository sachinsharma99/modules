<?php
class IdentityController extends IdentityControllerCore
{
    public $auth = true;
    public $php_self = 'identity';
    public $authRedirection = 'identity';
    public $ssl = true;

    public $passwordRequired = true;

    /**
     * Assign template vars related to page content.
     *
     * @see FrontController::initContent()
     */
    public function initContent()
    {
        $should_redirect = false;

        $customer_form = $this->makeCustomerForm()->setPasswordRequired($this->passwordRequired);
        $customer = new Customer();

        $customer_form->getFormatter()
            ->setAskForNewPassword(true)
            ->setAskForPassword($this->passwordRequired)
            ->setPasswordRequired($this->passwordRequired)
            ->setPartnerOptinRequired($customer->isFieldRequired('optin'));

        if (Tools::isSubmit('submitCreate')) {
            $customer_form->fillWith(Tools::getAllValues());


            if(!empty(Configuration::get('SSSCUSTOMREGISTRATIONFIELDS_LIVE_MODE')) && Configuration::get('SSSCUSTOMREGISTRATIONFIELDS_LIVE_MODE') == true ) {

                    $this->checkExtraValidation(); /* check extra validation from ssscustomregistrationfield module */

                }


            if ($customer_form->submit()) {
                $this->success[] = $this->trans('Information successfully updated.', array(), 'Shop.Notifications.Success');
                $should_redirect = true;
            } else {
                $this->errors[] = $this->trans('Could not update your information, please check your data.', array(), 'Shop.Notifications.Error');
            }
        } else {
            $customer_form->fillFromCustomer(
                $this->context->customer
            );
        }

        $this->context->smarty->assign([
            'customer_form' => $customer_form->getProxy(),
        ]);

        if ($should_redirect) {
            $this->redirectWithNotifications($this->getCurrentURL());
        }

        parent::initContent();
        $this->setTemplate('customer/identity');
    }

    public function getBreadcrumbLinks()
    {
        $breadcrumb = parent::getBreadcrumbLinks();

        $breadcrumb['links'][] = $this->addMyAccountToBreadcrumb();

        return $breadcrumb;
    }

    private function checkExtraValidation() {

        $account_type = Tools::getValue('account_type');

        if(empty($account_type)) {

            $this->errors[] = $this->trans('Please select type of account.', array(), 'Shop.Notifications.Error');
            
        }

        if($account_type == 2) {
            if( empty(trim(Tools::getValue('company'))) ) {
                $this->errors[] = $this->trans('Company name should not be empty.', array(), 'Shop.Notifications.Error');
            }
        }
 
        if(count($this->errors) > 0) {

            return $this->redirectWithNotifications($this->getCurrentURL());
        }


    }
}