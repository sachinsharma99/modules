<?php 

class AuthController extends AuthControllerCore
{

	public $ssl = true;
    public $php_self = 'authentication';
    public $auth = false;

    public function checkAccess()
    {
        if ($this->context->customer->isLogged() && !$this->ajax) {
            $this->redirect_after = ($this->authRedirection) ? urlencode($this->authRedirection) : 'my-account';
            $this->redirect();
        }

        return parent::checkAccess();
    }

    public function initContent()
    {
        $should_redirect = false;

        if (Tools::isSubmit('submitCreate') || Tools::isSubmit('create_account')) {

            $register_form = $this
                ->makeCustomerForm()
                ->setGuestAllowed(false)
                ->fillWith(Tools::getAllValues());

            if (Tools::isSubmit('submitCreate')) {
                $hookResult = array_reduce(
                    Hook::exec('actionSubmitAccountBefore', array(), null, true),
                    function ($carry, $item) {
                        return $carry && $item;
                    },
                    true
                );

                if(!empty(Configuration::get('SSSCUSTOMREGISTRATIONFIELDS_LIVE_MODE')) && Configuration::get('SSSCUSTOMREGISTRATIONFIELDS_LIVE_MODE') == true ) {

                    $this->checkExtraValidation(); /* check extra validation from ssscustomregistrationfield module */

                }


                if ($hookResult && $register_form->submit()) {

                    $should_redirect = true;
                }
            }

            $this->context->smarty->assign([
                'register_form' => $register_form->getProxy(),
                'hook_create_account_top' => Hook::exec('displayCustomerAccountFormTop'),
            ]);
            $this->setTemplate('customer/registration');
        } else {
            $login_form = $this->makeLoginForm()->fillWith(
                Tools::getAllValues()
            );

            if (Tools::isSubmit('submitLogin')) {
                if ($login_form->submit()) {
                    $should_redirect = true;
                }
            }

            $this->context->smarty->assign([
                'login_form' => $login_form->getProxy(),
            ]);
            $this->setTemplate('customer/authentication');
        }

        parent::initContent();

        if ($should_redirect && !$this->ajax) {
            $back = urldecode(Tools::getValue('back'));

            if (Tools::urlBelongsToShop($back)) {
                // Checks to see if "back" is a fully qualified
                // URL that is on OUR domain, with the right protocol
                return $this->redirectWithNotifications($back);
            }

            // Well we're not redirecting to a URL,
            // so...
            if ($this->authRedirection) {
                // We may need to go there if defined
                return $this->redirectWithNotifications($this->authRedirection);
            }

            // go home
            return $this->redirectWithNotifications(__PS_BASE_URI__);
        }
    }


    private function checkExtraValidation() {

    	$account_type = Tools::getValue('account_type');

        if(empty($account_type)) {

        	$this->errors[] = $this->trans('Please select type of account.', array(), 'Shop.Notifications.Error');
    		
        }

        if($account_type == 2) {
        	if( empty(trim(Tools::getValue('company'))) ) {
        		$this->errors[] = $this->trans('Company name should not be empty.', array(), 'Shop.Notifications.Error');
        	}
        }
 
        if(count($this->errors) > 0) {

        	return $this->redirectWithNotifications($this->getCurrentURL());
        }


    }

    
}