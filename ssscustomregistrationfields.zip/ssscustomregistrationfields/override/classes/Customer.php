<?php
class Customer extends CustomerCore
{

    public $account_type;

    public function __construct($id = null)
	{

	if(!empty(Configuration::get('SSSCUSTOMREGISTRATIONFIELDS_LIVE_MODE')) && Configuration::get('SSSCUSTOMREGISTRATIONFIELDS_LIVE_MODE') == true ) {
		Customer::$definition['fields']['account_type'] = array('type' => self::TYPE_STRING, 'size' => 30);

	}
	parent::__construct($id);
	}


}

?>